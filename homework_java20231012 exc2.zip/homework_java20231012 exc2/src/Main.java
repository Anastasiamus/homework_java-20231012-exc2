import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Random r = new Random();
        int number1 = r.nextInt(1,9);
        int number2 = r.nextInt(1,9);
        int sum = number1*number2;
        System.out.println(number1);
        System.out.println(number2);
        System.out.println("Результат умножения первого числа на второе:  ? ");
        Scanner scn = new Scanner(System.in);
        int user = scn.nextInt();
        if (number1*number2 == sum) {
            System.out.println(true);;
        }else {
            System.out.println(false);
            System.out.printf("%d", sum);

        }
    }
}


// Программа генерирует два целых однозначных числа.
// Программа задаёт вопрос: результат умножения первого числа на второе?
// Пользователь должен ввести ответ и увидеть на экране правильно он ответил или нет.
// Если пользователь ответил неправильно, то программа должна показать правильный ответ.